# 执行平面

执行平面负责"把任务送到节点上执行并拿回结果"。它不感知 agent、会话和模型，只认识任务。

## 任务模型

任务 id 由服务端生成（UUIDv7），是执行平面里唯一的任务标识。

### 任务类型（v1）

| kind | 说明 |
|---|---|
| `exec` | 执行命令：`argv`（直接执行）或 `shell`（`sh -c`）；可选 `env`、`cwd`、`stdin`、超时 |
| `file.read` | 读文件，支持偏移和长度上限 |
| `file.write` | 原子写（临时文件 + rename）；可设置 mode/owner；可选 `expected_sha256` 做 CAS，防止覆盖并发修改 |
| `file.stat` | 文件元信息 |
| `file.list` | 列目录，有条目数上限 |

编辑类操作（`edit_file`）在服务端实现：先 `file.read`，计算修改结果，再带 `expected_sha256` 执行 `file.write`。客户端不需要理解 diff。

PTY 交互、文件传输等后续再加。

### 通用字段

```
task_id        UUIDv7
node_id
kind, spec     见上
privileged     true | false             # true 时为特权任务，走授权链路，见 privilege.md
authorization  可选：特权任务的授权（一个授权，需要联署时再加一个联署；本地批准时为空），见 privilege.md
timeout_ms     超时后先发 SIGTERM，宽限期过后发 SIGKILL（杀整个进程组）
output_limit   客户端为该任务缓冲输出的上限
```

### 状态机（服务端视角）

```
created ──▶ awaiting_approval ──▶ dispatched ──▶ running ──▶ exited(code)
   │               │                  │             │
   │               └──▶ rejected      │             ├──▶ failed(reason)      执行器层面的错误，例如命令不存在、授权校验失败
   └──▶ denied(策略拒绝)              │             ├──▶ cancelled
                                      └─────────────┴──▶ unknown(reason)
```

`unknown` 是执行平面唯一的"结果不确定"状态，reason 取值：

| reason | 触发条件 |
|---|---|
| `connection_lost` | 已下发的任务在终态之前连接断开，且断线恢复失败（SSH 节点一断即是） |
| `executor_restarted` | 重连后查询任务，客户端不认识这个任务 id（客户端进程重启过） |
| `dispatch_unconfirmed` | `start` 已发出但未收到 `accepted`，连接就断了 |

向 agent 报告的内容是："失败，状态未知，原因是 xxx"。是否重试、重试前要不要先检查机器状态，由 agent 或使用者决定。

### 不重复执行

- 同一个任务 id 的 `start` **最多下发一次**。
- 重连后服务端只对未终结的任务发 `query`，不会重新发 `start`。
- 客户端收到不认识的 `query` 时回复 `unknown_task`。

这三条保证任何情况下同一个任务都不会被执行两次。客户端不持久化任务，也不做任何重放。

## 输出

- 输出按流（stdout/stderr）分开，每个分片带字节偏移 `offset`，实时推送给 crhs。
- **crhs 只保存截断后的输出**：头部和尾部各一段（各 2000 行或 50KB，先到为准），不保存完整输出，也没有输出保留策略。
- **过长的输出由 crha 在节点上保存为普通文件**：输出超过 2000 行或 50KB（与交给模型的截断阈值相同，因此只要模型看到的输出被截断，就一定有完整输出文件；阈值随 `TaskStart` 下发）时，crha 非特权模式把完整输出写入 `[output].dir`（默认 `/var/lib/crha/output/<task_id>.log`，stdout 和 stderr 按时间顺序交错，每段带流标记），`TaskExit` 中带上文件路径和总字节数。文件权限 0600，属主为非特权模式的运行用户（输出可能包含敏感内容）。agent 需要完整输出时，用普通的 `read_file` 读取。
  - 特权任务的输出本来就经由非特权模式转发，所以同样由非特权模式保存，不会因此多暴露什么。
  - 这些文件的清理由 crha 负责，按 `crha.toml` 中 `[output]` 的 `max_age` 和 `max_total` 配置（默认 7 天、1GB）。
- **断线续传**：任务运行期间，以及结束后到 crhs 确认（`OutputAck`）之前，crha 保留未确认的输出：输出较短时在内存中，已经写入文件的直接从文件中补发。所以不会因为缓冲溢出而丢失输出。
- **SSH 节点**：强制截断，只有 crhs 保存的头尾，不支持保存完整输出。

## 自有协议

### 分层

```
消息层     Protobuf 消息（proto/ 下定义）
会话层     Hello / 心跳 / 断线恢复
安全层     Noise_IK 端到端加密通道（双向认证），见"通信安全"
传输层     任意可靠有序的消息流：
           v1：WebSocket over TLS（客户端主动连服务端，即"反向连接"，默认方式）
           后续：由服务端主动连客户端（节点有公网入口、服务端在内网时使用）
```

消息层、会话层和安全层都与传输解耦，新增传输方式时不需要改协议，也不需要重新设计认证。

### 消息草案

| 方向 | 消息 | 说明 |
|---|---|---|
| C→S | `Hello` | node_id、客户端版本、能力（支持的 kind、特权任务的处理方式、两种模式各自的运行身份）、运行中任务列表 `{task_id, state, stdout_end, stderr_end}` |
| S→C | `Welcome` | 附带对运行中任务的输出确认偏移，客户端从这里续传（双向认证已在 Noise 握手中完成） |
| C→S | `Facts` | 系统信息：发行版、内核、架构、init 系统、包管理器、sudo/doas/run0 是否可用；节点笔记路径；节点所属的组（配置变化时主动推送） |
| S→C | `TaskStart` | 任务规格 + 授权凭证 |
| C→S | `TaskAccepted` / `TaskRejected` | 接受，或拒绝（附原因，例如不支持的 kind、授权校验失败） |
| C→S | `TaskOutput` | `{task_id, stream, offset, data}` |
| S→C | `OutputAck` | `{task_id, stream, offset}`，确认后客户端可以释放缓冲 |
| C→S | `TaskExit` | 退出码 / 信号 / 执行器错误，最终输出偏移；完整输出文件的路径（如果有） |
| S→C | `TaskCancel` | 取消（TERM → 宽限期 → KILL） |
| S→C | `TaskQuery` / C→S `TaskStatus` | 查询状态；不认识的任务回复 `unknown_task` |
| S→C | `TrustQuery` / C→S `TrustSummary` | 查询特权模式的信任配置；配置变化时客户端主动推送，见 privilege.md |
| S→C | `Preflight` / C→S `PreflightResult` | 询问特权模式哪些信任项可以授权某个任务 |
| S→C | `Revocations` | 下发吊销列表，由非特权模式转交特权模式 |
| 双向 | `Ping` / `Pong` | 心跳，用于更快发现断线 |

### 断线恢复

- 网络中断时客户端进程还在，任务继续运行，输出继续缓冲。
- 客户端以指数退避重连，在 `Hello` 中带上运行中的任务列表；服务端回复各任务的确认偏移，客户端从该偏移补发输出。
- 服务端发现有未终结的任务不在客户端的列表中，就发 `TaskQuery` 确认；客户端回复 `unknown_task` 后，任务标记为 `unknown(executor_restarted)`。
- 断线超过一定时间（可配置），服务端先把这些任务对上层报告为 `unknown(connection_lost)`；如果之后客户端重连并报告了结果，再以"迟到结果"补记到审计和任务记录中，但不会改变已经返回给 agent 的结论。

## 通信安全

### 威胁模型

| 攻击者 | 设计目标 |
|---|---|
| 网络中间人：窃听、篡改、重放 | 什么都做不到 |
| 终结 TLS 的第三方：反代、CDN、Cloudflare Tunnel 等 | 只能看到密文，无法注入消息 |
| 被盗的注册令牌 | 一次性、有效期短，且注册必须经过确认 |
| 被攻破的节点 | 只能看到发给自己的任务，也只能操作这些任务；无法冒充其他节点 |
| 被攻破的 crhs | 可以向节点下发普通命令；提权受 crha 特权模式的信任配置约束，见 privilege.md |

如果只用 TLS，终结 TLS 的一方就能看到全部明文，还能注入 `TaskStart`，等于拿到所有节点的普通用户 RCE。所以在 TLS 之内再加一层端到端加密。

### 两层结构

- **外层：WSS（TLS 1.3）**。只负责穿透网络和隐藏元数据。证书验证方式 `tls_verify` 可选 `system`（默认）或 `none`；服务端用自签证书时设为 `none` 不会降低安全性。
- **内层：Noise 通道**。`Noise_IK_25519_ChaChaPoly_BLAKE2s`，prologue 为 `"crh/1"`。IK 表示客户端事先知道服务端的静态公钥（注册时固定下来）。1 个往返完成双向认证，具备前向保密。

### 握手

1. crha → crhs：携带客户端静态公钥（加密传输），载荷为 `{node_id, crha 版本, 单调时间戳}`。crhs 按公钥找到节点，找不到或节点未被批准就断开。
2. crhs → crha：载荷为 `{连接 id, 服务端时间}`。之后进入 `Hello` 和断线恢复流程。

- **防重放**：IK 的第一条消息可以被重放。crhs 记住每个节点最后一次握手的时间戳，拒绝不比它更新的握手（与 WireGuard 的 TAI64N 做法相同）。即使被重放，攻击者没有客户端的临时私钥，也无法解开后续流量。
- **分帧**：一个 WebSocket 二进制消息承载一个 Noise 传输消息。Noise 单条消息上限 64KB，所以输出分片不超过 60KB。
- **密钥更新**：连接最长存活 24 小时，到期后主动重连并重新握手。断线恢复本来就很便宜，所以不单独实现 rekey。

### 实现

- Go：`flynn/noise`。
- TS：基于 Node 内置的 `crypto`（x25519、chacha20-poly1305、blake2s256）实现握手状态机，用 Noise 官方测试向量验证，并在 CI 中与 Go 实现交叉测试。

### 密钥

| 持有方 | 密钥 | 算法 | 用途 | 泄露后果 |
|---|---|---|---|---|
| crhs | 服务端身份密钥 | X25519 | Noise 通道 | 冒充 crhs，向节点下发普通命令（不能提权） |
| crhs | 授权签名密钥 | ssh-ed25519 | 签发授权与联署，见 privilege.md | 在信任 crhs 的节点上，在其信任项允许的范围内提权 |
| crhs | 主密钥 | 32 字节对称密钥 | 加密 `secrets` 表 | SSH 私钥、模型 API key 等泄露 |
| crha | 节点身份密钥 | X25519 | Noise 通道 | 冒充这个节点 |

- 节点身份密钥存放在 `/var/lib/crha/identity.key`，权限 0600，属主为 crha 用户。
- crhs 的主密钥从 `crhs.toml` 中 `master_key_file` 指定的文件读取，不写进数据库。
- crhs 的身份私钥（轮换期间包括新旧两把）和授权签名私钥（不使用 ssh-agent 时）用主密钥加密后存放在 `secrets` 表中。

### 密钥导出

数据库备份只包含加密后的私钥，没有主密钥就无法恢复。所以 crhs 从一开始就提供密钥导出和导入：

- `crhs keys export --out crhs-keys.age`：导出主密钥、crhs 身份私钥（含轮换中的旧密钥）、授权签名私钥。签名密钥由 ssh-agent 托管时只导出公钥，并在导出结果中注明。
- 导出文件用 [age](https://age-encryption.org/) 格式、口令加密（scrypt），口令在导出时交互输入。可以用标准的 `age` 工具解密核对，不依赖 crhs。
- `crhs keys import crhs-keys.age`：在新部署（或重建）时导入，配合数据库备份完成恢复。导入时检查数据库中的公钥与导出文件一致。
- 只提供本地命令行，不通过 WebUI 或 API 导出：需要能读取 `crhs.toml` 和主密钥文件，也就是能登录 crhs 所在的主机。每次导出都写入审计。
- 恢复 = 数据库备份 + 密钥导出文件。crha 节点不需要导出：节点身份密钥丢失时重新注册即可。

### 注册

1. 用户在 WebUI 创建注册令牌（节点将归这个用户所有），格式为 `crh1.<服务端身份公钥指纹>.<随机密钥>`。令牌只能使用一次，有效期默认 1 小时，可以限定节点名。
2. 在节点上执行 `crha enroll https://crh.example.com crh1.xxxx.yyyy`：
   - 通过 HTTPS 获取服务端身份公钥，**检查它与令牌中的指纹一致**，然后固定下来。令牌本身就完成了信任引导，做法与 kubeadm 的 `--discovery-token-ca-cert-hash` 相同。
   - 生成节点身份密钥，发起 Noise IK 握手，在载荷中提交令牌密钥、主机名和 Facts。令牌密钥在 Noise 通道内传输，终结 TLS 的一方看不到。
3. crhs 校验令牌后，节点进入 **pending** 状态。**注册必须经过确认**：令牌的创建者（节点所有者）或管理员在 WebUI 核对主机名和节点公钥指纹（节点上可以用 `crha status` 查看指纹）后批准，才分配 node_id 并允许它接收任务。

### 轮换与吊销

- **吊销节点**：crhs 删除它的公钥，下次握手即失败；已建立的连接立即断开。
- **轮换节点密钥**：执行 `crha rotate-key`，在已认证的连接上提交新公钥，crhs 切换后旧密钥作废。
- **轮换服务端身份密钥**：crhs 可以同时持有新旧两把密钥。通过已认证的连接把新公钥推送给所有节点，节点同时固定新旧两把；过渡期结束后移除旧密钥。过渡期内一直不在线的节点需要重新注册。

### crha 本地策略（可选）

`/etc/crha/crha.toml` 中可以配置节点自己的限制，例如 `allow_kinds`、`read_only`，用来约束 crhs 能让 crha 非特权模式做什么。即使 crhs 被攻破，这些限制依然有效。

## crha 的重载与升级

- **reload**：`crha reload`（或者给进程发 SIGHUP）让两种模式重新读取配置。特权模式重载信任配置后，向 crhs 推送新的 `TrustSummary`。新配置校验失败时继续使用旧配置，并向 crhs 报告错误。涉及连接的配置（服务端地址、身份密钥）变化时，非特权模式重新连接。
- **修改配置**：就是普通的特权任务：`file.write` 写配置文件，再执行 `crha reload`。
- **升级**：同样是普通的特权任务：
  1. `file.write` 写入新的二进制（或者 `exec` 调用包管理器安装）；
  2. `exec crha upgrade --apply <路径>`：校验新二进制能运行并报告版本，原子替换，然后通过 `systemd-run --on-active=2s` 延迟重启服务。这样当前任务可以先上报结果，再被重启打断。
- 重启会让节点上正在运行的任务变为 `unknown(executor_restarted)`。crhs 在下发升级任务前提示还有哪些任务在运行，并可以选择等它们结束。

## SSH 传输

SSH 节点不安装任何东西，服务端通过 SshTransport 执行，对上层提供与自有客户端相同的任务接口。

| 能力 | 自有客户端 | SSH |
|---|---|---|
| exec / 文件操作 | ✅ | ✅（exec 走 exec channel；文件操作优先用 SFTP，没有 SFTP 时退回到 exec） |
| 断线续传 | ✅ | ❌ 连接一断，任务即为 `unknown(connection_lost)` |
| 反向连接 | ✅ | ❌ 服务端必须能访问节点的 SSH 端口 |
| 特权任务 | 四种处理方式（见 privilege.md） | 只支持 `native`（`sudo -n` / `doas -n` / `run0`，非交互）、`ignore`（SSH 用户本身就是目标身份时）、`reject` |
| 节点本地日志 | 特权模式本地日志 + journald | 只有系统自带日志（sshd、sudo） |

### 跳板机

SSH 节点可以配置一个或多个跳板（等价于 OpenSSH 的 `ProxyJump`）：

- 每一跳单独配置主机、端口、用户、凭证，并**分别固定主机密钥**；
- 跳板可以引用另一个已登记的 SSH 节点，也可以是只用于跳转的独立配置；
- 实现上用 `ssh2` 在上一跳上 `forwardOut` 出到下一跳的 TCP 通道，逐级建立连接；
- 任何一跳断开，都等同于连接中断，任务为 `unknown(connection_lost)`。

实现要点：

- 主机密钥固定：首次连接时展示指纹，由添加节点的用户确认后存储；之后严格校验。
- 凭证：私钥加密存储在数据库中，或者使用服务端进程可访问的 ssh-agent。
- 取消与超时：命令外层包一层 wrapper，先输出进程组 id，再 `exec` 真正的命令；需要取消时另开 channel 执行 `kill -TERM -<pgid>`。
- 每个节点复用一条 SSH 连接，在上面开多个 channel。
