# ClusterRightHand 设计文档

ClusterRightHand（下称 CRH）是一个用于管理 VPS 集群的 agent 平台：服务端运行多会话 agent loop，把指令下发给各节点上的客户端执行；同时也可以不用内置 agent，直接作为 MCP 服务器把节点集群暴露给任意 coding agent。

> 状态：设计阶段，尚未开始实现。本目录记录已对齐的需求与设计决策。
>
> 许可证：MIT。

## 文档索引

| 文档 | 内容 |
|---|---|
| [architecture.md](architecture.md) | 总体架构、组件划分、技术栈、仓库结构 |
| [execution-plane.md](execution-plane.md) | 执行平面：任务模型与语义、客户端协议、通信安全（WSS + Noise）、节点注册、SSH 传输 |
| [privilege.md](privilege.md) | 提权与授权：特权任务的四种处理方式、crha 特权模式、方法与目标、授权结构、信任数组、联署、preflight |
| [agent-runtime.md](agent-runtime.md) | Agent 运行时：pi-durable 集成、fleet 工具、会话、subagent、测试策略 |
| [access-control.md](access-control.md) | 用户模型（管理员 / 普通用户、用户组）、归属与分享、授权规则、API token、审计 |
| [scheduling.md](scheduling.md) | 计划任务 |
| [mcp.md](mcp.md) | MCP 门面 |
| [data-model.md](data-model.md) | 数据表草案 |
| [roadmap.md](roadmap.md) | 里程碑 |

## 产品定位

核心特征：

1. 服务端与客户端职责明确：服务端维护 agent loop，客户端只做"接收 → 执行 → 反馈"和"提权 → 授权"两条链路，不感知 agent。
2. 客户端可以通过多种方式接入：SSH（无需安装），或者自有客户端二进制 + 独立协议（支持断线续传、反向连接）。
3. 服务端支持多个 agent 会话、会话内 subagent、计划任务、提权管理、审计。
4. 可以只作为 MCP 服务器使用，把节点集群提供给外部 coding agent。
5. 提权授权可以完全由用户掌握：节点可以配置为"服务端无法提权，只有用户签名才能提权"。

与同类产品的区别：

| 产品 | CRH 的区别 |
|---|---|
| Cenvero Fleet | 通过 MCP 暴露给任意 coding agent；内置多会话 agent loop |
| kagent | 不是 k8s 原生，不要求 k8s |
| InfiniShell / SSH MCP Server / Cloudssh | 有独立客户端，支持断线续传和反向连接；有独立服务端，支持持续运行和计划任务 |
| Hermes Agent / OpenClaw / nanobot | 多机管理是原生功能；agent loop 是多会话而非 claw-like |
| codex / claude / AionUI / Hope Agent | 多机管理是原生功能 |
| OpenHands | agent loop 在服务端执行；客户端不在临时 docker 中运行 |
| nuomiiiii/lite | 内置多会话 agent loop |
| ServerManager.ai | 目标对标对象，希望成为其开源替代 |

## 决策记录

| # | 决策 | 理由 / 被否决的方案 |
|---|---|---|
| D1 | 服务端 Node.js + React，客户端 Go | Node 可直接使用 pi SDK；Go 交叉编译简单、编译快、心智负担小 |
| D2 | 数据库通过 SQL 抽象层（Kysely）同时支持 SQLite 和 PostgreSQL | 单机自用可用 SQLite，团队部署用 PG |
| D3 | Agent 运行时采用 pi-durable + pi-ai，锁定精确版本，并隔离在自有 `AgentRuntime` 接口之后 | 持久会话、崩溃恢复、subagent、工具钩子与需求对应度最高。否决 pi-coding-agent SDK：面向本地单工作目录，存储为 JSONL 文件，扩展生态无法迁移到服务端场景。否决单用 pi-agent-core：需自研持久化、压缩、subagent |
| D4 | pi-durable 使用自研存储后端，基于 D2 的 SQL 抽象层实现 | 与业务数据同库；官方只提供 SQLite/JSONL/IndexedDB 等后端，没有 PG |
| D5 | Agent 和 MCP 都只是 Fleet 核心的调用方；策略、审批、审计都在 Fleet 核心里执行 | MCP 模式不应成为绕过审计的后门 |
| D6 | 执行平面只有一种失败语义：连接中断或客户端不认识任务 id 时，任务状态为 `unknown` | SSH 与自有客户端接口统一；不重放，避免重复执行 |
| D7 | 同一个任务 id 的 `start` 最多下发一次；重连后只用 `query` 查询 | 由此保证不会重复执行；否决 boot id 方案（多余） |
| D8 | SSH 模式不上传客户端二进制 | 避免处理目标架构的分发问题；代价是 SSH 节点没有续传、反连和特权模式 |
| D9 | 提权 IPC 使用 unix socket + `SO_PEERCRED` | 零依赖；否决 D-Bus（服务器上不一定有，且无必要） |
| D10 | 每个节点的 crha 特权模式在本地配置一个信任数组，用 `role`（`crhs` / `user` / `local`）区分角色、`format`（`sshsig` / `webauthn`）区分签名格式，每项可带防护规则 | "crhs 无法单独执行特权任务"就是 crhs 信任项不含 `execute`，或者不配置 crhs 信任项 |
| D11 | 授权统一为"本体 + 可选指令限制（前缀或原文）+ 可选截止时间"；计划任务也用它单独签发 | crhs 的单条命令授权就是 `exact` + 短截止时间，由信任项强制 |
| D12 | 用户模型一开始就做：单组织、多用户，表中预留 `org_id` | 当前只有一个用户，但后补的成本很高；用户类型见 D47 |
| D13 | 执行平面不加锁 | 并发冲突由 agent 和使用者自行处理 |
| D14 | 优先支持 Linux | |
| D15 | v1 只做 exec 和文件操作，PTY 后置 | 先做 agent 需要的最小集合 |
| D16 | 二进制命名：`crhs`（服务端）、`crha`（客户端）。对外联网的 crha 实例称为**非特权模式**，只通过本机 socket 提供服务、执行带授权任务的实例称为**特权模式**；同一个二进制还包含用户侧子命令 | |
| D17 | 配置文件统一使用 TOML | |
| D18 | 监控、告警、仪表盘暂不实现，但设计上预留扩展点，不能被现有设计阻塞 | 见 architecture.md 的"扩展预留" |
| D19 | crhs ↔ crha 通信使用 WSS 外层 + Noise_IK 内层端到端加密 | 终结 TLS 的反代或 CDN 只能看到密文；否决只用 mTLS |
| D20 | 节点注册必须经过确认，不自动接受；由节点所有者（令牌创建者）或管理员确认 | |
| D21 | crhs 的授权签名与用户 SSH key 一样使用 SSHSIG | 特权模式只剩 SSHSIG 和 WebAuthn 两条校验路径；crhs 私钥可以交给 ssh-agent 托管 |
| D22 | 用户信任项可以要求联署（`kinds` 中加 `require-cosign`）：每次使用都必须附带 crhs 的联署，此时该 crhs 信任项除角色和 `cosign` 能力之外的限制不生效 | |
| D23 | 暂不考虑主机内威胁：特权模式没有身份密钥，socket 不加密，查询结果不签名 | 非特权模式的伪造无法让特权模式执行未授权的命令 |
| D24 | 规则判定只在特权模式里做；crhs 通过 `TrustSummary` 和 `Preflight` 查询信任配置 | 避免 JS 与 RE2 语义不一致；审批只推送给能授权的用户 |
| D25 | 信任 Passkey 即接受"crhs 被控制时 Passkey 不提供保护"，不对 Passkey 的能力单独区分 | |
| D26 | 签名信任包暂不实现，设计上预留 | 见 privilege.md 的"扩展预留" |
| D27 | `kinds`：`execute`（可以单独授权特权任务）；crhs 角色另有 `cosign`（可以联署）；user 角色另有 `require-cosign`（每次使用必须联署）。联署只能来自 crhs 角色 | 用户之间互相联署在结构上就不可能出现；crhs 的单独授权和联署是两种独立的能力 |
| D28 | crha 的特权 / 非特权模式与 Linux 用户身份解耦。非特权模式通过 `[privileged].mode` 决定如何处理特权任务：`forward`（转给特权模式）/ `native`（sudo 等）/ `ignore`（直接以自身身份执行）/ `reject` | "特权"指"需要授权才能执行"，不等于 root；非特权模式可以以 root 运行，特权模式也可以以其他用户运行 |
| D29 | 授权与防护规则只区分三种方法：`exec`、`file.read`（含 stat、list）、`file.write`（包含 read）；规则为"方法（必填）+ 可选的前缀或正则"，`allow` 和 `deny` 都必须写方法 | 只做简单过滤，不引入规则引擎；避免路径规则与命令规则互相误放行 |
| D30 | `exact` 授权同时绑定完整任务规格的哈希（env、cwd、stdin、写入内容等）；特权文件操作的路径不允许包含符号链接 | 批准"写某个文件"时，批准的是写入那一份内容；防止用符号链接绕过路径规则 |
| D31 | crhs 的授权规则沿操作者链（用户 → 会话 → 子会话 …；用户 → API token；用户 → 计划任务 → 会话）逐级判定，取最严格的结果；取值为 allow / deny / require-approval，全不表态时为 require-approval | 与 crha 的信任配置是两码事；子会话只能收紧，由判定方式保证 |
| D32 | 每个 subagent 都是独立会话 | 有自己的规则和预算 |
| D33 | 预算是授权规则的一部分：用量计入链上所有级别，子级预算不超过父级剩余；不足时与审批一样向上反馈 | |
| D34 | SSH 传输支持跳板机，每一跳分别固定主机密钥 | |
| D35 | crha 支持 reload；自更新和修改配置（包括信任配置）都是普通的特权任务 | 不需要单独的升级通道；信任配置的修改同样受信任配置约束 |
| D36 | 节点笔记是节点上的一个普通 Markdown 文件，路径可查询；`node_info` 自动返回路径和截断后的内容；读写和审计与普通文件操作相同 | |
| D37 | 需要审批时沿链向上传递：上一级对该操作为 allow 的 agent 会话可以判断（批准 / 拒绝 / 上交），否则继续向上，最终到用户 | 上一级 agent 在自己的会话中处理，见 D41 |
| D38 | 原生支持批量执行：`exec`、`read_file`、`write_file` 接受节点和组的列表，Fleet 核心以任务组管理 | |
| D39 | 节点用组组织，取代标签；组只在 crha 本地配置中定义，crhs 侧只是缓存（连接时上报、变化时推送）；特权模式本地配置的组是授权依据（发给组的授权视为发给自己） | 组成员关系以节点本地配置为准，crhs 无法绕过授权扩大授权范围；SSH 节点的组在 crhs 中维护 |
| D40 | crhs 只保存截断后的输出头尾；过长的输出由 crha 在节点上保存为普通文件并负责清理，agent 用 `read_file` 读取；SSH 节点强制截断，不保存完整输出 | 去掉 crhs 的输出存储和保留策略；断线续传可以直接从文件补发 |
| D41 | 前台 subagent 的等待可以被打断并自动转入后台，父会话处理请求后显式调用 `subagent_wait`；父会话的其他工具返回时自动提示待处理的子会话 | 父会话在自己的上下文中处理子会话的审批和预算请求 |
| D42 | 工具和会话的默认值沿用 pi 作为 coding agent 时的默认值：输出交给模型时保留尾部 2000 行或 50KB，超过即落盘；读文件 2000 行或 50KB 分页；无默认超时；压缩与重试参数相同 | 见 agent-runtime.md 的"默认值"；落盘阈值与模型截断阈值相同，模型看到截断时一定有完整输出文件 |
| D43 | OIDC 暂不实现，设计上预留：登录方式与用户身份分开，密码可以为空，预留外部身份关联表和用户组来源字段 | 见 access-control.md 的"扩展预留：OIDC" |
| D44 | 节点和会话都明确属于一个用户，可以分享给额外的用户或用户组（节点：`view` / `operate`；会话：`view` / `chat`）；会话始终以所有者的身份行事 | 计划任务、API token 属于创建者，暂不分享 |
| D45 | 许可证：MIT | |
| D46 | crhs 提供密钥导出与导入（`crhs keys export` / `import`），导出文件为 age 口令加密，只能在本地命令行操作 | 数据库备份只含加密后的私钥，没有主密钥无法恢复 |
| D47 | 用户只有管理员和普通用户两种，不设角色和细粒度权限 | 能对节点做什么由"能否访问节点" + 操作者链上的授权规则决定 |

## 暂不处理

- **发送给模型提供商的敏感数据**：命令输出、文件内容会原样进入模型上下文，暂不做脱敏或"禁止发给模型"的标记。
- **扩展机制**：crhs 作为 MCP 客户端接入外部工具、运维手册（runbook）等，暂不考虑。
- 监控、告警、仪表盘（D18）、签名信任包（D26）、OIDC（D43）：不实现，但设计上预留。

## 待定问题

- **pi-durable 版本**：会话订阅推送频率的修复目前只在 main 分支（1.4.0 之后），需要等下一个发布版再锁定。见 [agent-runtime.md](agent-runtime.md#版本与升级)。
